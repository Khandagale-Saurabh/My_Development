<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?><?php
		require_once("connection.php");

		if(isset($_POST['submitform']) && !empty($_FILES["uploadfile"]["name"]))
		{
			$dir="upload/";
			$image=$_FILES['uploadfile']['name'];
			$temp_name=$_FILES['uploadfile']['tmp_name'];

			if($image!="")
			{
				if(file_exists($dir.$image))
				{
					$image= time().'_'.$image;
				}

				$fdir= $dir.$image;
				move_uploaded_file($temp_name, $fdir);
			}
                        

				$query="insert IGNORE into `images` (`id`,`file`) values ('','$image')";
                                
				mysqli_query($con,$query) or die(mysqli_error($con));
		                      
                                
                 echo"Photo Uploaded Successfully... ";

		}
                else
                {
                // echo"Double Tab to adjust ";
                 
                 
                 
                 
                
// PHP program to pop an alert 
// message box on the screen 
  
// Function defnition 
function function_alert($message) { 
      
    // Display the alert box  
    echo "<script>alert('$message');</script>"; 
} 
  
  
// Function call 
function_alert("Double tab to adjust"); 

function_alert("Please Increase Voulme");   

                 
                 
                 
                }

?>


	<?php  if (isset($_SESSION['username'])) : ?>
			<h1><p>Welcome  Back @<strong><?php echo  $_SESSION['username']; ?></strong></p></h1>
			<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
		<?php endif ?>







<!DOCTYPE html>
<html>
<head>
	<title>Saurabh Khandagale</title>

<link href='https://fonts.googleapis.com/css?family=Abel' rel='stylesheet'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<style>
table td:hover img
{
 transform:scale(1.2);
 border-style: double;
 filter: brightness(100%);
}








</style>




<style>
body.dark-mode {
  background-color: #111;
  color: #eee;
}
body.dark-mode a {
  color: #111;
}
body.dark-mode button {
  background-color: #eee;
  color: #111;
}

body.light-mode {
  background-color: #eee;
  color: #111;
}
body.light-mode a {
  color: #111;
}
body.light-mode button {
  background-color: #111;
  color: #eee;
}

$dark-color: #111;
$light-color: #eee;

body.dark-mode {
  background-color: $dark-color;
  color: $light-color;
  a {
    color: $dark-color;
  }
  button {
    background-color: $light-color;
    color: $dark-color;
  }
}

body.light-mode {
  background-color: $light-color;
  color: $dark-color;
  a {
    color: $dark-color;
  }
  button {
    background-color: $dark-color;
    color: $light-color;
  }
}
body {
 font-family: 'Abel';font-size: 22px;
}


</style>


<script>
function toggleDarkLight() {
  var body = document.getElementById("body");
  var currentClass = body.className;

body.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
}
</script>





</head>
<body id="body" class="light-mode">


  
  	<h4>[NIGHT/Day Mode]</h4>
                                       
   
  <button type="button" name="dark_light" onclick="toggleDarkLight()" title="Toggle dark/light mode"  class ="button">🌛</button>
  
<div>
<br>
<h3>Please Upload Your Photo and Be a Part Of It😁<h3>
					         
<form action="" method="post" enctype="multipart/form-data">
Upload Photo : <input type="file" name="uploadfile" class="button accept="image/*">
 
 	   </br>
						   <input type="text" value=<?php echo $_SESSION['username'];  ?> >
						    <button type="submit" name="submitform" class="button">Upload</button>
                                                    
                                                
                                                    
                                                    <style>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
.button {
  min-width: 80px;
  min-height: 60px;
  font-family: 'Nunito', sans-serif;
  font-size: 22px;
  text-transform: uppercase;
  letter-spacing: 1.3px;
  font-weight: 700;
  color: #313133;
  background: #4FD1C5;
background: linear-gradient(90deg, rgba(129,230,217,1) 0%, rgba(79,209,197,1) 100%);
  border: none;
  border-radius: 1000px;
  box-shadow: 12px 12px 24px rgba(79,209,197,.64);
  transition: all 0.3s ease-in-out 0s;
  cursor: pointer;
  outline: none;
  position: relative;
  padding: 10px;
  }

button::before {
content: '';
  box-shadow: 0 0 60px rgba(0,255,203,.64);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  opacity: 0;
  transition: all .3s ease-in-out 0s;
}

.button:hover, .button:focus {
  color: #313133;
  transform: translateY(-6px);
}

button:hover::before, button:focus::before {
  opacity: 1;
}

button::after {
  content: '';
  width: 30px; height: 30px;
  border-radius: 100%;
  border: 6px solid #00FFCB;
  position: absolute;
  z-index: -1;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation: ring 1.5s infinite;
}

button:hover::after, button:focus::after {
  animation: none;
  display: none;
}

@keyframes ring {
  0% {
    width: 30px;
    height: 30px;
    opacity: 1;
  }
  100% {
    width: 300px;
    height: 300px;
    opacity: 0;
  }
}




                                                    
                                                    </style>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
						</form>
			</div>

<div>
					
 <h2>People who are using it</h2>
 
 
 
     <table border="1" cellpadding="2" cellspacing="0"   
style="border-style: double";>
               <tr>
			
			<th>Photos Uploaded by users</th>
		</tr>
<?php
$i=1;
$sql="select * from `images`";

$qry=mysqli_query($con,$sql) or die(mysqli_error($con));

while($row=mysqli_fetch_array($qry))
{

?>
<tr>
                
                                                                        
			<td>
                        <img src="upload/<?php echo $row['file'];?>" height="450" width="450">
                         </td>
                                                         
 </tr>
                                                       
                                                        
				 <?php
				 			$i++;
				 		}
				 ?>

                                  </table>
                                  <audio controls autoplay>
    <source src="a1.mp4" type="audio/ogg">
  Your browser does not support the audio element.
</audio>

			</div>


  

</body>
</html>