
<?php
       
  $databaseHost = 'fdb26.awardspace.net';//or localhost
  $databaseName = '3433183_khandagale'; // your db_name
  $databaseUsername = '3433183_khandagale'; // root by default for localhost 
  $databasePassword = 'saurabh12345';  // by defualt empty for localhost
  

//$con=mysqli_connect("fdb26.awardspace.nett","3433183_khandagale", "saurabh12345","3433183_khandagale");

//$db =  mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
        
	$con =  mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>
	
      
        
  
	
 